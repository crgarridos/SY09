SY09
====

**sy09_tp01 : Statistique descriptive, Analyse en composantes principales.**
* Sujet : http://www4.utc.fr/~sy09/lib/exe/fetch.php?media=fr:tp1.pdf

**sy09_tp02 : Classification automatique.**
* Sujet : http://www4.utc.fr/~sy09/lib/exe/fetch.php?media=fr:tp2.pdf

**sy09_tp03 : Théorie de la décision.**
* Sujet : http://www4.utc.fr/~sy09/lib/exe/fetch.php?media=fr:tp3.pdf

**sy09_tp04 : Analyses discriminantes quadratique et linéaire.**
* Sujet : http://www4.utc.fr/~sy09/lib/exe/fetch.php?media=fr:tp4.pdf
