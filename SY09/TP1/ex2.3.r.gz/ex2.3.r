library(MASS)
data(crabs)
crabsquant<-crabs[,4:8];